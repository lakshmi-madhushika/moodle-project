<?php

defined('MOODLE_INTERNAL') || die();
require_once(dirname(__FILE__) . '/../../config.php');
//require_once(__DIR__.'/lib.php');

function block_graph_get_block_context($blockid) {
    if (class_exists('context_block')) {
        return context_block::instance($blockid);
    } else {
        return get_context_instance(CONTEXT_BLOCK, $blockid);
    }
}

function block_graph_get_course_context($courseid) {
    if (class_exists('context_course')) {
        return context_course::instance($courseid);
    } else {
        return get_context_instance(CONTEXT_COURSE, $courseid);
    }
}


// function block_graphs_get_students($course) {
//     global $DB;
//     $students = array();
//     $context = context_course::instance($course);
//     $allstudents = get_enrolled_users($context, 'block/graphs:bemonitored', 0,
//                     'u.id, u.firstname, u.lastname, u.email, u.suspended', 'firstname, lastname');
//     foreach ($allstudents as $student) {
//         if ($student->suspended == 0) {
//             if (groups_user_groups_visible($DB->get_record('course', array('id' =>  $course), '*', MUST_EXIST), $student->id)) {
//                 $students[] = $student;
//             }
//         }
//     }
//     return($students);
// }


function report_log_print_graph() {
    global  $OUTPUT,$DB;
//     echo  ("sdfghnjm");
//     global $DB;
//     $course = $DB->get_record('course', array('id' => $courseid), '*', MUST_EXIST);
//   foreach($course as $record){
//     echo $record;
// }

     echo  ("sdfghnjm");
    
   

    
    $course = $DB->get_records_sql('SELECT * FROM {course};');
    foreach($course as $record=>$new)
    {
        echo $new->id;
        echo '  ';
        echo $new->fullname;
        echo '  ';
        echo $new->shortname;
        echo '  ';
       
        echo '<br>';
}
$chart = new \core\chart_line();
//$chart= new \core\chart_line(array(array(4,23,14,6,11),'chart'));
//$chart->render();
    
    //   $logs['series1']=array('31','32','41','1');
    //   $logs['series2']=array('25','11','21','21');
    //   $logs['labels']=array('1','2','3','4');
    //   $series = new \core\chart_series('c1',$logs['series1']);
    //   $series2 = new \core\chart_series('c3', array('25','11','21','21'));
    //   $chart->add_series($series2);
    //   $chart->add_series($series2);
    //   $chart->set_title($title);
    //    $chart->set_labels(array('a','d','j','y'));
    //    $yaxis = $chart->get_yaxis(0, true);
    //    $yaxis->set_label("no.of student");
    //    $yaxis->set_stepsize(max(1, round(max(max($logs['series1']),max($logs['series2'])) / 10)));
     echo $OUTPUT->render($chart);
      
      
    // if (!is_object($user)) {
    //     $user = core_user::get_user($user);
    // }

    // $logmanager = get_log_manager();
    // $readers = $logmanager->get_readers();

    // if (empty($logreader)) {
    //     $reader = reset($readers);
    // } else {
    //     $reader = $readers[$logreader];
    // }
    // // If reader is not a sql_internal_table_reader and not legacy store then don't show graph.
    // if (!($reader instanceof \core\log\sql_internal_table_reader) && !($reader instanceof logstore_legacy\log\store)) {
    //     return array();
    // }
    // $coursecontext = context_course::instance($course->id);

    // $a = new stdClass();
    // $a->coursename = format_string($course->shortname, true, array('context' => $coursecontext));
    // $a->username = fullname($user, true);




// function report_log_usertoday_data($course, $user, $date, $logreader) {
//     $site = get_site();
//     $logs = [];

//     if ($course->id == $site->id) {
//         $courseselect = 0;
//     } else {
//         $courseselect = $course->id;
//     }

//     if ($date) {
//         $daystart = usergetmidnight($date);
//     } else {
//         $daystart = usergetmidnight(time());
//     }

//     for ($i = 0; $i <= 23; $i++) {
//         $hour = $daystart + $i * 3600;
//         $logs['series'][$i] = 0;
//         $logs['labels'][$i] = userdate($hour, "%H:00");
//     }

//     $rawlogs = report_log_userday($user->id, $courseselect, $daystart, $logreader);

//     foreach ($rawlogs as $rawlog) {
//         if (isset($logs['labels'][$rawlog->hour])) {
//             $logs['series'][$rawlog->hour] = $rawlog->num;
//         }
//     }

//     return $logs;
// }

// function report_log_userall_data($course, $user, $logreader) {
//     global $CFG;
//     $site = get_site();
//     $timenow = time();
//     $logs = [];
//     if ($course->id == $site->id) {
//         $courseselect = 0;
//     } else {
//         $courseselect = $course->id;
//     }

//     $maxseconds = REPORT_LOG_MAX_DISPLAY * 3600 * 24;  // Seconds.
//     if ($timenow - $course->startdate > $maxseconds) {
//         $course->startdate = $timenow - $maxseconds;
//     }

//     if (!empty($CFG->loglifetime)) {
//         $maxseconds = $CFG->loglifetime * 3600 * 24;  // Seconds.
//         if ($timenow - $course->startdate > $maxseconds) {
//             $course->startdate = $timenow - $maxseconds;
//         }
//     }

//     $timestart = $coursestart = usergetmidnight($course->startdate);

//     $i = 0;
//     $logs['series'][$i] = 0;
//     $logs['labels'][$i] = 0;
//     while ($timestart < $timenow) {
//         $timefinish = $timestart + 86400;
//         $logs['labels'][$i] = userdate($timestart, "%a %d %b");
//         $logs['series'][$i] = 0;
//         $i++;
//         $timestart = $timefinish;
//     }
//     $rawlogs = report_log_usercourse($user->id, $courseselect, $coursestart, $logreader);

//     foreach ($rawlogs as $rawlog) {
//         if (isset($logs['labels'][$rawlog->day])) {
//             $logs['series'][$rawlog->day] = $rawlog->num;
//         }
//     }

//     return $logs;
// }


//     // if ($typeormode == 'today' || $typeormode == 'userday.png') {
//     //     $logs = report_log_usertoday_data($course, $user, $date, $logreader);
//     //     $title = get_string("hitsoncoursetoday", "", $a);
//     // } else 
//     if ($typeormode == 'all' ) {
//         $logs = report_log_userall_data($course, $user, $logreader);
//         consol.log(count($logreader));
//         $title = get_string("hitsoncourse", "", $a);
//     }

//     //if (empty($CFG->preferlinegraphs)) {
      

    
//     $series = new \core\chart_series(get_string("hits"), $logs['series']);
//     //$series2 = new \core\chart_series(get_string("hits"), $logs['series']);
//     //$chart->add_series($series2);
//     $chart->add_series($series);
    
//     $chart->set_title($title);
//     $chart->set_labels($logs['labels']);
//     $yaxis = $chart->get_yaxis(0, true);
//     $yaxis->set_label(get_string("no.of student"));
//     $yaxis->set_stepsize(max(1, round(max($logs['series'])) / 10));




   
 }
