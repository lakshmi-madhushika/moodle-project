<?php

class block_graph extends block_base {

    public function init() {
        $this->title = get_string('config_default_title', 'block_graph');
    }

    public function has_config() {
        return true;
    }

    public function applicable_formats() {
        return array(
            'course-view'    => true,
            'site'           => true,
            'mod'            => false,
            'my'             => true
        );
    }

    public function get_content() {
        global $USER, $COURSE, $CFG, $OUTPUT, $DB;

        if ($this->content !== null) {
            return $this->content;
        }
        $this->content = new stdClass;
        $this->content->text = '';
        $this->content->footer = '';
       

             $parameters = array('graphid' => $this->instance->id, 'courseid' => $COURSE->id);
             $url = new moodle_url('/blocks/graph/overview.php', $parameters);
             $label = get_string('overview', 'block_graph');
             $options = array('class' => 'overviewButton');
       
             $this->content->text .= $OUTPUT->single_button($url, $label, 'post', $options);
         
        
         return $this->content;
        }    
}
