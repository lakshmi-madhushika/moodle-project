<?php



// require_once(dirname(__FILE__) . '/../../config.php');
// require_once($CFG->dirroot.'/blocks/graph/lib.php');

class block_graph_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        // global $CFG, $COURSE, $DB, $OUTPUT, $SCRIPT;
        // $loggingenabled = true;

        // if (block_progress_on_site_page()) {
        //     return;
        // }

        // // Check that logging is enabled in 2.7 onwards.
        // if (function_exists('get_log_manager')) {
        //     $logmanager = get_log_manager();
        //     $readers = $logmanager->get_readers();
        //     $loggingenabled = !empty($readers);
        //     if (!$loggingenabled) {
        //         $warningstring = get_string('config_warning_logstores', 'block_graph');
        //         $warning = $OUTPUT->notification($warningstring);
        //         $mform->addElement('html', $warning);
        //     }
        //}
    }
}