<?php

defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot.'/blocks/graph/lib.php');

    $settings->add(new admin_setting_heading('headconfig'),
        get_string('headerconfig', 'block_graph'),
        get_string('descconfig', 'block_graph'),
       
    );


    $settings->add(new admin_setting_configcheckbox('block_graph/Allow_HTML',
        get_string('descallowhtml', 'block_graph'),
        get_string('labelallowhtml', 'block_graph'),
    
    );
