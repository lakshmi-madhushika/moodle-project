<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Progress Bar block English language translation
 *
 * @package    contrib
 * @subpackage block_graph
 * @copyright  2010 Michael de Raadt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Module names.
$string['aspirelist'] = 'Aspire resource list';
$string['assign'] = 'Assignment';
$string['assignment'] = 'Assignment';
$string['book'] = 'Book';
$string['bigbluebuttonbn'] = 'Big Blue Button';
$string['certificate'] = 'Certificate';
$string['chat'] = 'Chat';
$string['choice'] = 'Choice';
$string['data'] = 'Database';
$string['dmelearn'] = 'Digital Media e-Learning';
$string['equella'] = 'Equella';
$string['feedback'] = 'Feedback';
$string['flashcardtrainer'] = 'Flashcard trainer';
$string['folder'] = 'Folder';
$string['forum'] = 'Forum';
$string['glossary'] = 'Glossary';
$string['hotpot'] = 'Hot Potatoes';
$string['hsuforum'] = 'Advanced Forum';
$string['imscp'] = 'IMS Content Package';
$string['journal'] = 'Journal';
$string['lesson'] = 'Lesson';
$string['lti'] = 'External tool';
$string['ouwiki'] = 'OU Wiki';
$string['page'] = 'Page';
$string['panopto'] = 'Panopto video';
$string['questionnaire'] = 'Questionnaire';
$string['quiz'] = 'Quiz';
$string['resource'] = 'File';
$string['recordingsbn'] = 'BBB Recordings';
$string['scorm'] = 'SCORM';
$string['subcourse'] = 'Subcourse';
$string['survey'] = 'Survey';
$string['turnitintool'] = 'Turnitin Tool';
$string['turnitintooltwo'] = 'Turnitin Tool 2';
$string['url'] = 'URL';
$string['video'] = 'Video';
$string['vpl'] = 'Virtual Programming Lab';
$string['wiki'] = 'Wiki';
$string['workshop'] = 'Workshop';
$string['jclic'] = 'JClic';
$string['geogebra'] = 'Geogebra';
$string['title'] = 'Over view of Course';

// Actions.
$string['activity_completion'] = 'activity completion';
$string['answered'] = 'answered';
$string['assessed'] = 'assessed';
$string['attempted'] = 'attempted';
$string['awarded'] = 'awarded';
$string['completed'] = 'completed';
$string['finished'] = 'finished';
$string['graded'] = 'graded';
$string['marked'] = 'marked';
$string['passed'] = 'passed';
$string['passedby'] = 'passed by deadline';
$string['passedscorm'] = 'passed';
$string['posted_to'] = 'posted to';
$string['responded_to'] = 'responded to';
$string['submitted'] = 'submitted';
$string['viewed'] = 'viewed';

// Stings for the Config page.
$string['config_default_title'] = 'Graph';
$string['config_group'] = 'Visible only to group';
$string['config_header_action'] = 'Action';
$string['config_header_expected'] = 'Expected by';
$string['config_header_icon'] = 'Icon';
$string['config_header_locked'] = 'Locked to deadline';
$string['config_header_monitored'] = 'Monitored';
$string['config_header_showsubmitted'] = 'Show submitted before action';
$string['config_icons'] = 'Use icons in bar';
$string['config_longbars'] = 'How to present long bars';
$string['config_now'] = 'Use';
$string['config_percentage'] = 'Show percentage to students';
$string['config_scroll'] = 'Scroll';
$string['config_squeeze'] = 'Squeeze';
$string['config_title'] = 'Alternate title';
$string['config_orderby'] = 'Order bar items by';
$string['config_orderby_due_time'] = '"Expected by" date-time';
$string['config_orderby_course_order'] = 'Ordering in course';
$string['config_warning_logstores'] = 'Warning: Logging is disabled so actions relying on views will not be checked.';
$string['config_warning_loglifetime'] = 'Warning: Logs are cleared after {$a} day(s). Actions relying on views will be affected by this.';
$string['config_wrap'] = 'Wrap';



// Other terms.
$string['addallcurrentitems'] = 'Add all activities/resources';
$string['mouse_over_prompt'] = 'Mouse over or touch bar for info.';
$string['no_events_config_message'] = 'There are no activities or resources to monitor the graph of. Create some activities and/or resources then configure this block.';
$string['no_events_message'] = 'No activities or resources are being monitored. Use config to set up monitoring.';
$string['no_visible_events_message'] = 'None of the monitored events are currently visible.';
$string['now_indicator'] = 'NOW';
$string['pluginname'] = 'Graph';
$string['selectitemstobeadded'] = 'Select activities/resources';
$string['showallinfo'] = 'Show all info';
$string['time_expected'] = 'Expected';
$string['tick'] = 'Tick';
$string['cross'] = 'Cross';

// Global setting strings
// Default colours that may have different cultural meanings.
// Note that these defaults can be overridden by the block's global settings.
$string['attempted_colour'] = '#73A839';
$string['submittednotcomplete_colour'] = '#FFCC00';
$string['notAttempted_colour'] = '#C71C22';
$string['futureNotAttempted_colour'] = '#025187';
$string['attempted_colour_title'] = 'Attempted colour';
$string['attempted_colour_descr'] = 'HTML Colour code for elements that have been attempted';
$string['submittednotcomplete_colour_title'] = 'Submitted but not complete colour';
$string['submittednotcomplete_colour_descr'] = 'HTML colour code for elements that have been submitted, but are not yet complete';
$string['notattempted_colour_title'] = 'Not-attempted colour';
$string['notattempted_colour_descr'] = 'HTML colour code for current elements that have not yet been attempted';
$string['futurenotattempted_colour_title'] = 'Future Not-attempted colour';
$string['futurenotattempted_colour_descr'] = 'HTML colour code for future elements that have not yet been attemted';
$string['coursenametoshow'] = 'Course name to show on Dashboard';
$string['shortname'] = 'Short course name';
$string['fullname'] = 'Full course name';
$string['showinactive'] = 'Show inactive students in Overview';
$string['wrapafter'] = 'When wrapping, limit rows to';
$string['defaultlongbars'] = 'Default presentation for long bars';

// Overview page strings.
$string['lastonline'] = 'Last in course';
$string['overview'] = 'Overview of students';
$string['graph'] = 'Graph';
$string['graphchart'] = 'Graphchart';

// For capabilities.
$string['graph:overview'] = 'View course overview of graphs for all students';
$string['graph:addinstance'] = 'Add a new graph block';
$string['graph:myaddinstance'] = 'Add a graph block to My home page';
$string['graph:showbar'] = 'Show the bar in the graph block';

// For Cache.
$string['cachedef_cachedlogs'] = 'Graph log query caching';

// For My home page.
$string['no_blocks'] = "No Graph blocks are set up for your courses.";
$string['no_courses'] = "You are not enrolled in any courses. Only bars from enrolled courses will be shown.";
