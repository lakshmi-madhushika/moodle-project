<?php


//defined('MOODLE_INTERNAL') or die("Direct access to this location is not allowed.");

$capabilities = array (
    // 'block/graph:overview' => array (
    //     'riskbitmask'   => RISK_PERSONAL,
    //     'captype'       => 'read',
    //     'contextlevel'  => CONTEXT_BLOCK,
    //     'archetypes'    => array (
    //         'teacher'        => CAP_ALLOW,
    //         'editingteacher' => CAP_ALLOW,
    //         'manager'        => CAP_ALLOW,
    //         'coursecreator'  => CAP_ALLOW,
    //     )
    // ),

    // 'block/graph:showbar' => array (
    //     'captype'       => 'read',
    //     'contextlevel'  => CONTEXT_BLOCK,
    //     'archetypes'    => array (
    //         'teacher'        => CAP_ALLOW,
    //         'editingteacher' => CAP_ALLOW,
    //         'student'        => CAP_ALLOW,
    //         'manager'        => CAP_ALLOW,
    //         'coursecreator'  => CAP_ALLOW,
    //     )
    // ),

    'block/graph:addinstance' => array(
        'riskbitmask' => RISK_SPAM | RISK_XSS,
        'captype' => 'write',
        'contextlevel' => CONTEXT_BLOCK,
        'archetypes' => array(
            // 'editingteacher' => CAP_ALLOW,
            'manager'        => CAP_ALLOW,
            // 'coursecreator'  => CAP_ALLOW
        ),

        'clonepermissionsfrom' => 'moodle/site:manageblocks'
    ),

    'block/graph:myaddinstance' => array(
        //'riskbitmask' => RISK_PERSONAL,
        'captype' => 'read',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes' => array(
            'user' => CAP_ALLOW,
        ),

        'clonepermissionsfrom' => 'moodle/my:manageblocks'
    ),
);
