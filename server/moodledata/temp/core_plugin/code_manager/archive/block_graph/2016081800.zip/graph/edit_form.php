<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 * Progress Bar block configuration form definition
 *
 * @package    contrib
 * @subpackage block_progress
 * @copyright  2010 Michael de Raadt
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(dirname(__FILE__) . '/../../config.php');
require_once($CFG->dirroot.'/blocks/graph/lib.php');

/**
 * Progress Bar block config form class
 *
 * @copyright 2010 Michael de Raadt
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_graph_edit_form extends block_edit_form {

    protected function specific_definition($mform) {
        global $CFG, $COURSE, $DB, $OUTPUT, $SCRIPT;
        $loggingenabled = true;

        // The My home version is not configurable.
        if (block_progress_on_site_page()) {
            return;
        }

        // Check that logging is enabled in 2.7 onwards.
        if (function_exists('get_log_manager')) {
            $logmanager = get_log_manager();
            $readers = $logmanager->get_readers();
            $loggingenabled = !empty($readers);
            if (!$loggingenabled) {
                $warningstring = get_string('config_warning_logstores', 'block_graph');
                $warning = $OUTPUT->notification($warningstring);
                $mform->addElement('html', $warning);
            }
        }
    }
}